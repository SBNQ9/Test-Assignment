package com.test.Assignment.service;

import java.util.List;

import com.test.Assignment.model.Video;

public interface VideoServiceInt {

	public List<Video> getVideos(); 
}
