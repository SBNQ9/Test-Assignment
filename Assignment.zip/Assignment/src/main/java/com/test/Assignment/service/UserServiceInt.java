package com.test.Assignment.service;

import java.util.List;

import com.test.Assignment.model.User;

public interface UserServiceInt {

	public List<User> getUsersList();
}
